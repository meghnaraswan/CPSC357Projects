//
//  TabViewDemoApp.swift
//  Shared
//
//  Created by iMan on 4/12/22.
//

import SwiftUI

@main
struct TabViewDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
